==============
Version 4.5.20
==============

Version 4.5.20 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.5.20

Bugs Fixed
----------

* Installation on MacOS X using ``setup.py`` or ``pip`` would fail if Xcode
  9.0 was installed.
